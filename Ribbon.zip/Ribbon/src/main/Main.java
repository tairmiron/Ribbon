package main;

import java.util.Scanner;
import constant.Enums.StateMenu;
import vacuumRobot.VacuumRobot;

public class Main {

	public static void main(String[] args) {
		Scanner sc = null;
		int userChoice = -1;

		// First time print menu.
		VacuumRobot.getInstance().printMenu();

		try {
			StateMenu state = VacuumRobot.getInstance().getState();

			do {
				sc = new Scanner(System.in);

				// Check if it's valid input
				if (sc.hasNextInt()) {
					userChoice = sc.nextInt();
					sc.nextLine();

					System.out.println("\n");

					// Do the actions that are chosen by user input.
					VacuumRobot.getInstance().menuChoose(userChoice, sc);
				} else {
					System.out.println("\nWrong input! Please insert a integer input.\n");
					VacuumRobot.getInstance().printMenu();
				}
			} while ((userChoice != 0 && state == StateMenu.Main) || state == StateMenu.Robot);
		} finally {
			if (sc != null)
				sc.close();
			VacuumRobot.getInstance().stopAllTimerThread();
		}

	}

}

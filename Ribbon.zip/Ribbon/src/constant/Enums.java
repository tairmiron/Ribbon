package constant;

public class Enums {
    public enum RobotStatus {
        ACTIVE, REBOOT, CLEAN, FAILURE
    }

    public enum RobotModel {
        V1, V2, V3
    }

    public enum SensorState {
        UP,
        DOWN
      }

    public enum StateMenu {
        Main, Robot
    }
    
}

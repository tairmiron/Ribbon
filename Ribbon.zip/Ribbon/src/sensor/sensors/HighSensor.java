package sensor.sensors;

import constant.Enums.SensorState;
import sensor.Sensor;

public class HighSensor extends Sensor{

    public HighSensor(String name, SensorState state) {
        super(name, state);
    }
    
}

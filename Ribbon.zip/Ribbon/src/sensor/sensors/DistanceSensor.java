package sensor.sensors;

import constant.Enums.SensorState;
import sensor.Sensor;

public class DistanceSensor extends Sensor {

    public DistanceSensor(String name, SensorState state) {
        super(name, state);
    }
    
}

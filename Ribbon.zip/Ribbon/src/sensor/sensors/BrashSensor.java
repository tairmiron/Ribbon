package sensor.sensors;

import constant.Enums.SensorState;
import sensor.Sensor;

public class BrashSensor extends Sensor{

    public BrashSensor(String name, SensorState state) {
        super(name, state);
    }
    
}

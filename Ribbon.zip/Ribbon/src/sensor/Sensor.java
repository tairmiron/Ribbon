package sensor;

import constant.Enums.SensorState;

public abstract class Sensor {
	protected String sensorName;
	protected SensorState sensorState;

	public Sensor(String name, SensorState state){
		sensorName = name;
		sensorState = state;
	}

	public String getSensorName(){
		return sensorName;
	}

	public SensorState getSensorState(){
		return sensorState;
	}
}

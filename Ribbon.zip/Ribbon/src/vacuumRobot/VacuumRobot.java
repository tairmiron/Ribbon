
package vacuumRobot;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;

import constant.Enums.StateMenu;
import robot.Robot;

public class VacuumRobot {

	private static VacuumRobot instance = null;
	private static ArrayList<Robot> robotArray = new ArrayList<Robot>();
	private static Robot CurrentRobot;
	private static StateMenu State = StateMenu.Main;

	public static VacuumRobot getInstance() {
		if (instance == null)
			return new VacuumRobot();
		else
			return instance;
	}

	public void printMenu() {
		if (State == StateMenu.Main)
			printMainMenu();
		else
			printRobotMenu();
	}

	private void printMainMenu() {
		System.out.println(" ---- Main Menu ---- ");
		System.out.println("1 - Add new robot");
		System.out.println("2 - Choose robot");
		System.out.println("0 - quit \n");
	}

	private void robotNotFound() {
		System.out.println(" ---- Sorry! we couldn't find the robot you search. ---- \n\n");
		State = StateMenu.Main;
		printMenu();
	}

	private void printRobotMenu() {
		if (CurrentRobot == null) {
			robotNotFound();
			return;
		}
		System.out.println(" ---- " + CurrentRobot.getName() + " - Robot Menu" + " ---- " + "\n");
		System.out.println("1 - Clean");
		System.out.println("2 - Reboot");
		System.out.println("3 - Delete");
		System.out.println("4 - Fix");
		System.out.println("5 - Back to main manu \n");

	}

	public void menuChoose(int userChoice, Scanner sc) {
		// Menu options for user.
		if (State == StateMenu.Main)
			mainMenuChoose(userChoice, sc);
		else
			robotMenuChoose(userChoice);
	}

	private void mainMenuChoose(int userChoice, Scanner sc) {
		// Secure that the state isn't what we ask.
		if (State == StateMenu.Robot)
			return;

		switch (userChoice) {
			case 0:
				System.out.println("Hope you enjoy ! Bye Bye...\n");
				break;
			case 1:
				addNewRobot(sc);
				printMenu();
				break;
			case 2:
				chooseRobot(sc);
				break;
			default:
				System.out.println("Wrong Command\n");
				printMenu();
				break;
		}
	}

	private void robotMenuChoose(int userChoice) {
		// Secure that the state isn't what we ask.
		if (State == StateMenu.Main)
			return;

		// Robot actions.
		if (userChoice >= 1 && userChoice < 5)
			CurrentRobot.doAction(userChoice);

		// Back to main menu.
		else if (userChoice == 5)
			State = StateMenu.Main;
		else {
			System.out.println("Wrong Command\n");
		}
		printMenu();
	}

	private void chooseRobot(Scanner sc) {
		// Check if user have some robot.
		if (robotArray.size() == 0) {
			System.out.println("Sorry but you don't have robots yet.\n");
			printMenu();
			return;
		}

		// Change menu state to robot menu.
		State = StateMenu.Robot;

		// Display robot list.
		printRobotList();

		int robotIndex;

		do {
			if (sc.hasNextInt()) {
				// Get user input.
				robotIndex = sc.nextInt() - 1;

				// Check if the robot exist.
				if (robotIndex < robotArray.size() && robotIndex >= 0)
					CurrentRobot = robotArray.get(robotIndex);
				else {
					robotNotFound();
					return;
				}
			} else {
				robotNotFound();
				return;
			}
		} while (robotIndex >= robotArray.size() || robotIndex < 0);

		printMenu();
	}

	private void printRobotList() {
		System.out.println(" ---- Choose robot: ---- \n");
		for (int i = 0; i < robotArray.size(); i++) {
			System.out.println((i + 1) + " - " + robotArray.get(i).getName());
		}
		System.out.println("\n");
	}

	public void deleteRobot(UUID id) {
		CurrentRobot.stopTimerThread();
		robotArray.removeIf(robot -> robot.getId() == id);
	}

	public void addRobot(Robot robot) {
		robotArray.add(robot);
	}

	public void addNewRobot(Scanner sc) {
		String userName;
		String robotModel;
		String wifiName;

		userName = getUserName(sc);

		robotModel = getRobotModel(sc);

		wifiName = getWifiName(sc);

		submit(sc, userName, robotModel, wifiName);

	}

	public void submit(Scanner sc, String userName, String robotModel, String wifiName) {
		// Create new Robot object.
		Robot robot = new Robot(userName, robotModel, wifiName);

		// run the Robot object as thread.
		Thread thread = new Thread(robot);
		thread.start();

		// Add robot to robot array
		addRobot(robot);

		// Print robot details.
		robot.printRobot();
	}

	public String getWifiName(Scanner sc) {
		System.out.println("Insert wifi name: ");
		String wifiName = sc.nextLine();
		System.out.println("\n");
		return wifiName;
	}

	public String getRobotModel(Scanner sc) {
		String str;
		System.out.println("Choose a robot model: ");
		do {
			System.out.println("1 - V1 , 2 - V2 , 3 - V3");
			str = sc.nextLine();
			System.out.println("\n");
		} while (!str.equals("1") && !str.equals("2") && !str.equals("3"));

		return str;
	}

	public String getUserName(Scanner sc) {
		System.out.println(" ---- Add a new Robot - Please fill the information ---- \n");
		System.out.println("username: ");
		String userName = sc.nextLine();
		System.out.println("\n");
		return userName;
	}

	public void setState(StateMenu value) {
		State = value;
	}

	public StateMenu getState() {
		return State;
	}

	public void stopAllTimerThread() {
		// Run on the array and kill every thread.
		for (int i = 0; i < robotArray.size(); i++) {
			robotArray.get(i).stopTimerThread();
		}
	}

}

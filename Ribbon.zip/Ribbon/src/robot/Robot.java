package robot;

import java.text.DecimalFormat;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import constant.Enums.RobotModel;
import constant.Enums.RobotStatus;
import constant.Enums.SensorState;
import constant.Enums.StateMenu;
import robot.interfaces.IRobot;
import sensor.Sensor;
import sensor.sensors.BrashSensor;
import sensor.sensors.DistanceSensor;
import sensor.sensors.HighSensor;
import vacuumRobot.VacuumRobot;

public class Robot implements IRobot, Runnable {
	private UUID Id;
	private String Name;
	private String WifiName;
	private RobotModel Model;
	private RobotStatus Status;

	// We will assume that there are only 3 sensors.
	private Sensor[] Sensors = new Sensor[3];
	private Timer timer = new Timer();

	public Robot(String name, String robotModel, String wifiName) {
		Name = name;
		WifiName = wifiName;
		initialModel(robotModel);
		Id = UUID.randomUUID();
		initialStatus();
		initialSensors();
	}

	private void initialStatus() {
		// Get random number.
		String str = getRandomNumber();
		float rnd = Float.parseFloat(str);

		// Robot status will set in probability of 80% to Success and 20% to faild.
		if (rnd > 0.8) {
			System.out.println("FAILD\n");
			Status = RobotStatus.FAILURE;
			return;
		}

		System.out.println("SUCCESS\n");
		Status = RobotStatus.ACTIVE;
	}

	private String getRandomNumber() {
		// Return a random number between 0 to 1 in 0.X format.
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(1);
		return df.format(Math.random() * 1);
	}

	private void initialModel(String robotModel) {
		// We will assume that there are only 3 models.
		switch (robotModel) {
			case "1":
				Model = RobotModel.V1;
				break;
			case "2":
				Model = RobotModel.V2;
				break;
			case "3":
				Model = RobotModel.V3;
				break;
			default:
				System.out.println("wrong insert\n");
				break;
		}
	}

	private void initialSensors() {
		if (Model == RobotModel.V1)
			buildModelV1();
		else if (Model == RobotModel.V2)
			buildModelV2();
		else
			buildModelV3();
	}

	private void buildModelV1() {
		Sensors[0] = new HighSensor("High sensor", SensorState.DOWN);
		Sensors[1] = new DistanceSensor("Distance sensor", SensorState.UP);
		Sensors[2] = new BrashSensor("Brash sensor", SensorState.DOWN);
	}

	private void buildModelV2() {
		Sensors[0] = new HighSensor("High sensor", SensorState.DOWN);
		Sensors[1] = new DistanceSensor("Distance sensor", SensorState.UP);
		Sensors[2] = new BrashSensor("Brash sensor", SensorState.UP);
	}

	private void buildModelV3() {
		Sensors[0] = new HighSensor("High sensor", SensorState.UP);
		Sensors[1] = new DistanceSensor("Distance sensor", SensorState.UP);
		Sensors[2] = new BrashSensor("Brash sensor", SensorState.UP);
	}

	public void printRobot() {
		System.out.println("UserName: " + Name + ", RobotModel: " + Model + ", WifiName: " + WifiName + ", Status: "
				+ Status + "\n");
	}

	public String getName() {
		return Name;
	}

	public UUID getId() {
		return Id;
	}

	public RobotStatus getStatus() {
		return Status;
	}

	public void doAction(int userChoice) {
		if (userChoice == 1)
			clean();
		else if (userChoice == 2)
			reboot();
		else if (userChoice == 3)
			delete();
		else if (userChoice == 4)
			fix();
	}

	public void clean() {
		// Check if robot is active.
		if (Status != RobotStatus.ACTIVE) {
			System.out.println("Robot " + Name + " is not active\n");
			return;
		}

		// Change to Clean state.
		Status = RobotStatus.CLEAN;
		System.out.println("Robot " + Name + " is cleaning\n");
		
		try {
			// Wait 10 sec as reboot and change to active
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Return to Active state.
		Status = RobotStatus.ACTIVE;
		System.out.println("Cleaning done! Robot " + Name + " is Active\n");

	}

	public void reboot() {
		// Change to Reboot state.
		Status = RobotStatus.REBOOT;
		System.out.println("Robot " + Name + " is rebooting\n");

		try {
			// Wait 10 sec as reboot and change to active
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Return to Active state.
		Status = RobotStatus.ACTIVE;
		System.out.println("Rebboting done! Robot " + Name + " is Active\n");
	}

	public void fix() {
		// Check if robot is active.
		if (Status != RobotStatus.FAILURE) {
			System.out.println("Nothing to fix in robot '" + Name + "'\n");
			return;
		}

		// Fix the sensors.
		for (int i = 0; i < Sensors.length; i++) {
			if (Sensors[i].getSensorState() != SensorState.DOWN)
				System.out.println("Fixing sensor '" + Sensors[i].getSensorName() + "'\n");
		}
	}

	public void delete() {
		// Delete robot by id.
		VacuumRobot.getInstance().deleteRobot(Id);

		// Change the menu state to 'Main' to back to the main menu.
		VacuumRobot.getInstance().setState(StateMenu.Main);
		System.out.println("Robot '" + Name + "' deleted successfully ! :)\n");
	}

	public void stopTimerThread(){
		// After delete a robot the timer thread will stop.
		timer.cancel();
	}

	@Override
	public void run() {
		// Every 1 min Robot status will changed with probability of 50%.
		timer.schedule(new TimerTask() {

			@Override
			public void run() {

				String str = getRandomNumber();
				float rnd = Float.parseFloat(str);

				if (rnd < 0.5)
					Status = RobotStatus.FAILURE;
				else
					Status = RobotStatus.ACTIVE;
			}

		}, 0, 60000);
	}

}

package robot.interfaces;

public interface IRobot {
    public void doAction(int userChoice);
    public void clean();
    public void reboot();
    public void fix();
}
